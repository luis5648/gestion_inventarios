create definer = root@localhost trigger equiposAD
    after DELETE
    on equipos
    for each row
    INSERT INTO delEquiposRes(ID_EQUIPO,DESCRIPCION,USUARIO_QUE_ELIMINA,FECHA)
	VALUES (OLD.ID_Equipo,OLD.Descripcion,OLD.ID_Usuario, NOW());

