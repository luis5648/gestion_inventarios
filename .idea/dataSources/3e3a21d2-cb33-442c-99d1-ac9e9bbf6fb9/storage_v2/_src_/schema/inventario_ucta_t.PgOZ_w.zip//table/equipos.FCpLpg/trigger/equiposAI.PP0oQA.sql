create definer = root@localhost trigger equiposAI
  after INSERT
  on equipos
  for each row
  INSERT INTO insrtEquiposRes(ID_EQUIPO, DESCRIPCION, MODELO, N_SERIE, UBICACION,
															MARCA, ID_CATEGORIA, ID_PROPIETARIO, USUARIO_QUE_INSERTA, FECHA)
	VALUES (NEW.ID_Equipo,NEW.Descripcion,NEW.Modelo, NEW.N_serie, NEW.Ubicacion,NEW.Marca,
					(SELECT Nombre_Categoria from categoria where ID_Categoria = NEW.ID_Categoria),(SELECT Nombre_Propietario
					from propietario where ID_Propietario =  NEW
					  .ID_Propietario),NEW
					  .ID_Usuario,NOW());

